<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Intro to PHP</title>
    <meta charset="utf-8">
  </head>
  <body>
    <?php
      //$name = "Martin";
      //echo $name;
      //$favNumber = 7;
      //echo $favNumber;
      //echo "<h1>Hello World!</h1>";
    ?>
    <!-- <p>Information about PHP.</p> -->
    <?php
      //echo "<p>";
      //echo "<p>" . date("l") . "</p>";
      //echo "</p>";
      //$animal = "dog";
      //echo "Hello World";
      //echo "<p>" . $animal . "</p>";
      //echo ddate("l");
      //echo rand(1,10000);
      echo round(8.8445);
    ?>
  </body>
</html>
